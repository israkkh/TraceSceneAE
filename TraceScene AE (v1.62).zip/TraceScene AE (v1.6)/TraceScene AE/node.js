// Node.js v22+ ES module version for AE integration
// No node-fetch, no require

import fs from 'fs';
import path from 'path';
import { FormData } from 'node:formdata';

// Get file path from AE
const filePath = process.argv[2];
if (!filePath) {
    console.log(JSON.stringify({ error: "No file path provided" }));
    process.exit(1);
}

async function searchImage(filePath) {
    try {
        // Prepare the image for upload
        const formData = new FormData();
        formData.append('image', fs.createReadStream(filePath), path.basename(filePath));

        // Send POST request to trace.moe API
        const response = await fetch('https://api.trace.moe/search', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        // Output JSON so AE script can parse it
        console.log(JSON.stringify(data));
    } catch (err) {
        console.log(JSON.stringify({ error: err.message }));
    }
}

searchImage(filePath);
